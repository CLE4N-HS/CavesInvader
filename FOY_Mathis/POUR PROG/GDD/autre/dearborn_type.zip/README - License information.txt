EN > You�ve just downloaded the DEARBORN TYPE font (2017).

DEARBORN TYPE font has been created by Lukas Krakora and is free for non-commercial use only!

If you want to use the font commercially please contact me at my email krraaa@yahoo.com to get the information about pricing.

I can add any extra characters or customize the font for purchasers of the commercial license.

Any donations from non-commercial users to my Paypal krraaa@yahoo.com are welcome. 

Please do not distribute this font and do not upload it to any font web page at your own will. 

But you can link to its original location on Dafont, Fontspace or 1001fonts. 

You can visit my web site typewriterfonts.net for more typewriter and other fonts.

Thank you.

LK


CZ > Prave jste si stahli font DEARBORN TYPE (2017).

Font DEARBORN TYPE byl vytvoren Lukasem Krakorou a je volne ke stazeni a pouziti avsak pouze pro nekomercni ucely!

V pripade zameru vyuzit font komercne me prosim kontaktujte na emailu krraaa@yahoo.com a dozvite se cenu.

V pripade potreby mohu zajemcum o komercni licenci pridat k fontu dalsi znaky nebo libovolne upravit existujici.

Jakekoliv financni prispevky od nekomercnich uzivatelu na muj Paypal krraaa@yahoo.com jsou vitany.

Font prosim dale nedistribujte a nezavesujte ho na zadne stranky z vlastniho uvazeni. 

Muzete vsak svobodne odkazovat na jeho puvodni umisteni na Dafontu, Fontspace nebo 1001fonts.

Pro vice fontu ala psaci stroj, ale i jin�ch, navstivte moje stranky typewriterfonts.net.

Diky.

LK
